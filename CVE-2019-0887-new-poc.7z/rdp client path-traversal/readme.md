# compile

## patch_dll

1. use visual studio open poc/patch_dll/patch_dll.sln
2. select x64/release, compile it. 

> path **efile** in poc/patch_dll/patch_dll/dllmain.cpp is a path **exist both in guest and host**. Here I set it to `".\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\users\\public\\evil.txt"`

## inject_exe

use visual studio open poc/inject_exe/inject_exe.sln

choose x64/release, compile it.

# Useage 


1. create folder C:\\tmp in guest

2. put poc\patch_dll\x64\Release\patch_dll.dll to guest **C:\\tmp\\poc.dll**

3. put poc\inject_exe\x64\Release\inject_exe.exe to guest **C:\tmp\inject_exe.exe**

4. put easyhook\easyhook64.dll to guest **C:\windows\system32\\**

5. create a file that **efile** specified.

   > here we create a file in C:\\users\\public\\evil.txt

6. in guest, run C:\tmp\inject_exe.exe, if success, it will create a file log.txt in guest C:\tmp\

   > it should contain "load ok hook ok"

7. do a ctrl+c in host, then do a ctrl+v

8. a file evil.txt should exist in C:\users\public\eveil.txt

